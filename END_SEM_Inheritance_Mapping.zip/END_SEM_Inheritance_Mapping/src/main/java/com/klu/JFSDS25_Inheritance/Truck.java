package com.klu.JFSDS25_Inheritance;



import jakarta.persistence.Entity;

@Entity
public class Truck extends Vehicle {
    public int getLoadCapacity() {
		return loadCapacity;
	}

	public void setLoadCapacity(int loadCapacity) {
		this.loadCapacity = loadCapacity;
	}

	private int loadCapacity;

    // Getters and Setters
}

