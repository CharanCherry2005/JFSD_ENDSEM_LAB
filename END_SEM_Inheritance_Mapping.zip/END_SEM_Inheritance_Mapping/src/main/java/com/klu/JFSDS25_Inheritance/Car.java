package com.klu.JFSDS25_Inheritance;




import jakarta.persistence.Entity;

@Entity
public class Car extends Vehicle {
    private int numberOfDoors;

    // Getters and Setters
    
	public void setNumberOfDoors(int numberOfDoors) {
		this.numberOfDoors = numberOfDoors;
	}
	public void setnumberOfDoors(int numberOfDoors) {
		this.numberOfDoors = numberOfDoors;
	}
	
}
